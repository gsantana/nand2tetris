class Label < Command
  def codes
    [
      "(#{arg1})"
    ]
  end
end

