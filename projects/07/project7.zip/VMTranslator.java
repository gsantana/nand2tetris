import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class VMTranslator {

public static void main(String[] args) {
    Parser p = new Parser(args[0]);
    
    File f = new File(args[0]);
    CodeWriter c = new CodeWriter(f);
    
    while(p.hasMoreCommands()){
        Command command = p.advance();
        if(command.isAritimetic())
            c.WriteArithmetic(command);
        
        if(command.isPushPop())
            c.WritePushPop(command);
    }
    
    c.Close();
}
}
