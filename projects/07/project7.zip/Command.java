import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;
import java.util.UUID;

public class Command {

public enum Type {
    C_ARITIMETIC, C_PUSH, C_POP, C_LABEL, C_GOTO, C_IF, C_FUNCTION, C_RETURN, C_CALL;
}

private Type _Type;
private String action;
private String Arg1;
private String Arg2;
private String VmCode;
private List<String> hackCodes;

public Command(String type, String arg1, String arg2, String vmcode) {

    VmCode = "//" + vmcode;

    Set<String> aritimetic = new HashSet<String>(Arrays.asList(new String[] {
            "add", "sub", "neg", "eq", "gt", "lt", "and", "or", "not" }));

    action = type;

    if (aritimetic.contains(type))
        _Type = Type.C_ARITIMETIC;
    else if (type.equals("pop"))
        _Type = Type.C_POP;
    else if (type.equals("push"))
        _Type = Type.C_PUSH;

    Arg1 = arg1;
    if (arg2 != null && _Type != null)
        Arg2 = arg2;
}

public boolean isAritimetic() {
    return this._Type == _Type.C_ARITIMETIC;
}

public boolean isPushPop() {
    return (this._Type == _Type.C_POP) || (this._Type == _Type.C_PUSH);
}

public List<String> getHackArithmeticCommands() {
    List<String> codes = new ArrayList<String>();
    codes.add(VmCode);
    //codes.add("@12345");

    if (action.equals("add")) {
        codes.addAll(pop());
        codes.addAll(pointToValue());
        codes.add("M=M+D");
        codes.addAll(incrementStack());
    }

    if (action.equals("sub")) {
        codes.addAll(pop());
        codes.addAll(pointToValue());
        codes.add("M=M-D");
        codes.addAll(incrementStack());
    }

    if (action.equals("neg")) {
        codes.addAll(pop());
        codes.add("D=-D");
        codes.add("M=D");
        codes.addAll(incrementStack());
    }

    if (action.equals("eq")) {
        codes.addAll(logicCommands("JEQ"));
    }

    if (action.equals("gt")) {
        codes.addAll(logicCommands("JGT"));
    }

    if (action.equals("lt")) {
        codes.addAll(logicCommands("JLT"));
    }

    if (action.equals("and")) {
        codes.addAll(pop());
        codes.addAll(pointToValue());
        codes.add("M=M&D");
        codes.addAll(incrementStack());
    }

    if (action.equals("or")) {
        codes.addAll(pop());
        codes.addAll(pointToValue());
        codes.add("M=M|D");
        codes.addAll(incrementStack());
    }

    if (action.equals("not")) {
        codes.addAll(pointToValue());
        codes.add("M=!M");
        codes.addAll(incrementStack());
    }

    return codes;
}

public List<String> getHackPushPopCommands(String fileName) {
    List<String> codes = new ArrayList<String>();
    codes.add(VmCode);
    //codes.add("@12345");

    if (action.equals("push")) {
        if (Arg1.equals("constant")) {
            codes.add("@" + Arg2);
            codes.add("D=A");
            codes.addAll(pointToTopStack());
            codes.add("M=D");
            codes.addAll(incrementStack());
        }
        
        if (Arg1.equals("local")) {
            codes.addAll(push("LCL"));
        }
        
        if (Arg1.equals("argument")) {
            codes.addAll(push("ARG"));
        }
        
        if (Arg1.equals("this")) {
            codes.addAll(push("THIS"));
        }
        
        if (Arg1.equals("that")) {
            codes.addAll(push("THAT"));
        }
        
        if (Arg1.equals("static")) {           
            codes.add("@"+Arg2);
            codes.add("D=A");
            codes.add("@"+fileName);
            codes.add("A=D+A");
            codes.add("D=M");
            codes.addAll(pointToTopStack());
            codes.add("M=D");
            codes.addAll(incrementStack());
        }
        
        if (Arg1.equals("temp")) {
            codes.add("@"+Arg2);
            codes.add("D=A");
            codes.add("@5");
            codes.add("A=D+A");
            codes.add("D=M");
            codes.addAll(pointToTopStack());
            codes.add("M=D");
            codes.addAll(incrementStack());
        }
        
        if (Arg1.equals("pointer")) {
            if (Arg2.equals("0")) {
                codes.add("@THIS");    
            }
            if (Arg2.equals("1")) {
                codes.add("@THAT");    
            }
            codes.add("D=M");
            codes.addAll(pointToTopStack());
            codes.add("M=D");
            codes.addAll(incrementStack());
        }
    }
    
    if (action.equals("pop")) {       
        if (Arg1.equals("local")) {
            codes.addAll(pop("LCL"));
        }
        
        if (Arg1.equals("argument")) {
            codes.addAll(pop("ARG"));
        }
        
        if (Arg1.equals("this")) {
            codes.addAll(pop("THIS"));
        }
        
        if (Arg1.equals("that")) {
            codes.addAll(pop("THAT"));
        }
        
        if (Arg1.equals("static")) {          
            codes.add("@"+Arg2);
            codes.add("D=A");
            codes.add("@"+fileName);
            codes.add("D=D+A"); 
            codes.add("@stackvalue");
            codes.add("M=D");
            codes.addAll(pointToValue());
            codes.add("D=M");
            codes.add("@stackvalue");
            codes.add("A=M");
            codes.add("M=D");
        }
        
        if (Arg1.equals("temp")) {
            codes.add("@"+Arg2);
            codes.add("D=A");
            codes.add("@5");
            codes.add("D=D+A");
            codes.add("@stackvalue");
            codes.add("M=D");
            codes.addAll(pointToValue());
            codes.add("D=M");
            codes.add("@stackvalue");
            codes.add("A=M");
            codes.add("M=D");
        }
        
        if (Arg1.equals("pointer")) {            
            codes.addAll(pointToValue());
            codes.add("D=M");
            if (Arg2.equals("0")) {
                codes.add("@THIS");    
            }
            if (Arg2.equals("1")) {
                codes.add("@THAT");    
            }
            codes.add("M=D");
        }
    }

    return codes;
}

public List<String> pop(String segment) {
    List<String> codes = new ArrayList<String>();
    
    codes.add("@"+Arg2);
    codes.add("D=A");
    codes.add("@"+segment);
    codes.add("D=D+M"); 
    codes.add("@stackvalue");
    codes.add("M=D");
    codes.addAll(pointToValue());
    codes.add("D=M");
    codes.add("@stackvalue");
    codes.add("A=M");
    codes.add("M=D");
    
    return codes;
}

public List<String> push(String segment) {
    List<String> codes = new ArrayList<String>();
    codes.add("@"+Arg2);
    codes.add("D=A");
    codes.add("@"+segment);
    codes.add("A=D+M");
    codes.add("D=M");
    codes.addAll(pointToTopStack());
    codes.add("M=D");
    codes.addAll(incrementStack());
    return codes;
}

public List<String> logicCommands(String jump) {
    List<String> codes = new ArrayList<String>();

    UUID uniqueKey = UUID.randomUUID();
    codes.addAll(pop());
    codes.addAll(pointToValue());
    codes.add("D=M-D");
    codes.add("@JUMP"+uniqueKey);
    codes.add("D," + jump);
    codes.add("@SP");
    codes.add("A=M");
    codes.add("M=0");
    codes.add("@END"+uniqueKey);
    codes.add("0;JMP");
    codes.add("(JUMP"+uniqueKey+")");
    codes.add("@SP");
    codes.add("A=M");
    codes.add("M=-1");
    codes.add("(END"+uniqueKey+")");
    codes.addAll(incrementStack());

    return codes;
}

public List<String> pop() {
    List<String> codes = new ArrayList<String>();

    codes.addAll(pointToValue());
    codes.add("D=M");
    return codes;
}

public List<String> pointToValue() {
    List<String> codes = new ArrayList<String>();

    codes.addAll(decrementStack());
    codes.add("A=M");
    return codes;
}

public List<String> pointToTopStack() {
    List<String> codes = new ArrayList<String>();

    codes.add("@SP");
    codes.add("A=M");
    return codes;
}

public List<String> decrementStack() {
    List<String> codes = new ArrayList<String>();

    codes.add("@SP");
    codes.add("M=M-1");
    return codes;

}

public List<String> incrementStack() {
    List<String> codes = new ArrayList<String>();

    codes.add("@SP");
    codes.add("M=M+1");
    return codes;

}

public Type getType() {
    return _Type;
}

public String GetVMCode() {
    return VmCode;

}
}
    