import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.File;
import java.util.List;

public class CodeWriter {

private PrintWriter out;

private String fileName;

public CodeWriter(File file) {
    try {
        
       // fileName = file;
        fileName = file.getName().substring(0, file.getName().lastIndexOf("."));
        String outputFile = file.getAbsolutePath().replaceAll(".vm", ".asm");;
        
        File f = new File(outputFile);
        if (f.exists())
            f.delete();

        f.createNewFile();

        out = new PrintWriter(new BufferedWriter(new FileWriter(outputFile,
                true)));

    } catch (Exception e) {
        System.out.println(e);
        return;
    }
}

public void WriteArithmetic(Command command) {
    List<String> codes = command.getHackArithmeticCommands();
    for (String code : codes) {
        out.println(code);
    }
}

public void WritePushPop(Command command) {
    List<String> codes = command.getHackPushPopCommands(fileName);
    for (String code : codes) {
        out.println(code);
    }
}

public void Close() {
    out.close();
}
}
