import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Parser {

private List<Command> commands;
private int currentLine;

public Parser(String file) {
    try {
        currentLine = 0;
        commands = new ArrayList<Command>();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        for (String line = reader.readLine(); line != null; line = reader.readLine()) {
            Command command = CreateCommand(line);
            if(command.getType() != null)
            {
                commands.add(command);
            }
        }
        reader.close();
    } catch (Exception e) {
        System.out.println(e);
        return;
    }
}

private Command CreateCommand(String  line){
    String[] command_parts = line.split("\\W+");
    String arg1 = null;
    String arg2 = null;
    if(command_parts.length == 2)
    {
      arg1 = command_parts[1];
    }
    else if(command_parts.length >= 3)
    {
      arg1 = command_parts[1];
      arg2 = command_parts[2];
    }

    return new Command(command_parts[0],arg1, arg2, line);
}

public Command advance() {
    Command command = commands.get(currentLine);
    currentLine++;
    
    return command;
}

public boolean hasMoreCommands() {
    return currentLine < commands.size();
}
}
